# AGE-GENDER-ETHNICITY-PREDICTION
Semester project for Machine Learning Project offered by IIITD.
